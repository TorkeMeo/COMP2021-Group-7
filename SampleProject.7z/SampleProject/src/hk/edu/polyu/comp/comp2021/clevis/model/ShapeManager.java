package hk.edu.polyu.comp.comp2021.clevis.model;

import java.util.*;

public class ShapeManager {
    private Map<String, Shape> shapes;
    private List<String> commandHistory;

    public ShapeManager() {
        shapes = new HashMap<>();
        commandHistory = new ArrayList<>();
    }

    public void addShape(Shape shape) {
        if (shapes.containsKey(shape.getName()))
            throw new IllegalArgumentException("Shape with name '" + shape.getName() + "' already exists");
        shapes.put(shape.getName(), shape);
    }

    public Shape getShape(String name) {
        Shape shape = shapes.get(name);
        if (shape == null)
            throw new IllegalArgumentException("Shape '" + name + "' not found");
        return shape;
    }

    public boolean containsShape(String name) { return shapes.containsKey(name); }

    public List<Shape> getAllShapes() {
        List<Shape> allShapes = new ArrayList<>(shapes.values());
        allShapes.sort((a, b) -> Integer.compare(b.getZIndex(), a.getZIndex()));
        return allShapes;
    }

    public void recordCommand(String command) { commandHistory.add(command); }

    public List<String> getCommandHistory() { return new ArrayList<>(commandHistory); }
}